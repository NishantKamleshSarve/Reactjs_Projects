import { useEffect, useState } from "react";

function RestaurantDetail() {
  const [restaurants, setRestaurants] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchRestaurants = async () => {
    try {
      const response = await fetch("http://localhost:5000/api/home", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          deviceId: "321312364633",
          latitude: "321312364633",
          longitude: "321312364633",
          location: "Frankfurt",
          user: "123456",
          email: "devkpandey@gmail.com",
          zipcode: "61348",
          sorting: "",
          country: "",
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const rawData = await response.json();
      console.log("Raw API data:", rawData);

      // If API returns an array, take first element, else use as is
      const data = Array.isArray(rawData) ? rawData[0] : rawData;
      console.log("Processed data:", data);

      if (data?.Restaurants && Array.isArray(data.Restaurants)) {
        setRestaurants(data.Restaurants);
      } else {
        console.error("No restaurants found or bad data structure:", data);
      }
    } catch (error) {
      console.error("Fetch failed:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRestaurants();
  }, []);

  // Basic open hours check (can be improved per restaurant)
  const isOpenNow = () => {
    const now = new Date();
    const hour = now.getHours();
    return hour >= 10 && hour < 15;
  };

  if (loading) return <p className="text-center">Loading...</p>;

  if (restaurants.length === 0)
    return <p className="text-center text-red-600">No restaurants available.</p>;

  return (
    <div className="p-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
      {restaurants.map((rest) => (
        <div
          key={rest.restroid || rest.id || rest.name} // fallback keys
          className="bg-white shadow-md rounded-xl overflow-hidden border"
        >
          <img
            src={rest.image || "/fallback.jpg"} // fallback image
            alt={rest.name || "Restaurant image"}
            className="w-full h-48 object-cover"
          />
          <div className="p-4">
            <h2 className="text-lg font-semibold">{rest.name || "Unnamed"}</h2>
            <p className="text-sm text-gray-600">{rest.cuisine || "Cuisine N/A"}</p>
            <p className="text-sm">{rest.address || "Address N/A"}</p>
            <p className="text-sm">
              {/* Min Delivery: €{rest.minimumdeliveryamount ?? "N/A"} */}
            </p>

            <p
              className={`mt-2 font-medium ${
                isOpenNow() ? "text-green-600" : "text-red-500"
              }`}
            >
              {isOpenNow() ? "Open Now" : "Closed"}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}

export default RestaurantDetail;
